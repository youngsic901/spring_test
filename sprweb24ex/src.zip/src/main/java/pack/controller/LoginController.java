package pack.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import pack.model.GogekDao;
import pack.model.GogekDto;
import pack.model.JikwonDao;
import pack.model.JikwonDto;

import java.util.HashMap;
import java.util.Map;

@Controller
public class LoginController {
    @Autowired
    private GogekDao gogekDao;

    @Autowired
    private JikwonDao jikwonDao;

    @PostMapping("gogeklogin")
    @ResponseBody
    public Map<String, Object> gogeklogin(@RequestParam("gogekno")int gogekno, @RequestParam("gogekname")String gogekname, HttpSession session) {
        GogekDto gogekDto = gogekDao.findGogekDamsaNo(gogekno);
        Map<String, Object> jikwonMap = null;
        if(gogekno == gogekDto.getGogekno() && gogekname.equals(gogekDto.getGogekname())) {
            System.out.println("good");
            session.setAttribute("idKey", gogekno);

            JikwonDto jikwonDto = jikwonDao.findJikwon(gogekDto.getGogekdamsano());
            jikwonMap = new HashMap<>();
            jikwonMap.put("datas", jikwonDto);

            return jikwonMap;
        } else {
            return jikwonMap;
        }
    }
}
